'use client'
import React, { useState } from 'react'
import Button from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Book, Gamepad2, Sparkles, Quote } from 'lucide-react'
import { motion } from 'framer-motion'

export default function Home() {
  const [sent, setSent] = useState(false)

  const services = [
    { icon: <Book className="w-10 h-10 text-pink-400" />, title: 'Atendimento Infantil', desc: 'Abordagem terapêutica voltada ao universo das crianças, utilizando jogos e atividades para facilitar a expressão emocional.' },
    { icon: <Gamepad2 className="w-10 h-10 text-yellow-400" />, title: 'Atendimento para Adolescentes', desc: 'Espaço seguro para lidar com emoções, identidade e desafios da adolescência de forma empática e acolhedora.' },
    { icon: <Sparkles className="w-10 h-10 text-orange-400" />, title: 'Orientação Familiar', desc: 'Apoio aos pais e responsáveis no processo de compreensão e fortalecimento dos vínculos familiares.' },
  ]

  function handleSubmit(e?: any) {
    if (e) e.preventDefault()
    // fake send - show success message
    setSent(true)
    setTimeout(()=> setSent(false), 6000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-yellow-50 to-pink-50 flex flex-col items-center text-center">
      <header className="w-full py-6 bg-white shadow-sm">
        <h1 className="text-3xl font-bold text-orange-500">Oficina da Mente</h1>
        <p className="text-sm text-gray-600">Psicologia & Comunidade</p>
      </header>

      <section className="max-w-4xl mt-10 px-6">
        <motion.h2 initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="text-4xl font-bold text-yellow-500">
          Cuidando da mente, com alegria e sensibilidade!
        </motion.h2>
        <p className="mt-4 text-gray-700 text-lg">
          Nossa clínica oferece um espaço acolhedor e especializado para o público infantojuvenil, unindo psicologia e ludicidade para promover o bem-estar emocional e o desenvolvimento saudável.
        </p>
        <Button className="mt-6 bg-orange-500 hover:bg-orange-600 text-white rounded-full px-6 py-3 text-lg shadow-md" onClick={()=>window.scrollTo({top:1000, behavior:'smooth'})}>
          Agende uma consulta
        </Button>
      </section>

      <section className="grid md:grid-cols-3 gap-6 mt-16 max-w-5xl px-6">
        {services.map((service, index) => (
          <motion.div key={index} whileHover={{ scale: 1.05 }} className="cursor-pointer">
            <Card className="shadow-md border-0 bg-white">
              <CardContent className="p-6 flex flex-col items-center text-center">
                {service.icon}
                <h3 className="text-xl font-semibold mt-4 text-orange-600">{service.title}</h3>
                <p className="mt-2 text-gray-600">{service.desc}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </section>

      <section className="bg-white py-16 mt-20 w-full">
        <h2 className="text-3xl font-bold text-orange-500 mb-8">O que os pais dizem</h2>
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto px-6">
          {[
            { quote: 'Meu filho adora as sessões! Ele se sente ouvido e acolhido.', name: 'Carla M.' },
            { quote: 'A equipe da Oficina da Mente transformou nossa rotina familiar.', name: 'João P.' },
            { quote: 'Ambiente encantador, com profissionais incríveis!', name: 'Renata L.' }
          ].map((item, index) => (
            <Card key={index} className="rounded-2xl shadow-sm border-0 bg-orange-50">
              <CardContent className="p-6 flex flex-col items-center text-center">
                <Quote className="w-8 h-8 text-yellow-500 mb-3" />
                <p className="text-gray-700 italic mb-2">“{item.quote}”</p>
                <span className="text-sm text-orange-600 font-semibold">— {item.name}</span>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="mt-20 max-w-3xl px-6 text-left">
        <h2 className="text-3xl font-bold text-orange-500 text-center mb-6">Agende uma Consulta</h2>
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-md p-8 space-y-4">
          <div>
            <label className="block text-gray-700 font-medium">Nome do responsável</label>
            <input required name="responsavel" type="text" className="w-full border border-gray-300 rounded-lg p-2 mt-1 focus:outline-none focus:ring-2 focus:ring-orange-400" placeholder="Seu nome" />
          </div>
          <div>
            <label className="block text-gray-700 font-medium">Nome da criança/adolescente</label>
            <input required name="paciente" type="text" className="w-full border border-gray-300 rounded-lg p-2 mt-1 focus:outline-none focus:ring-2 focus:ring-orange-400" placeholder="Nome do paciente" />
          </div>
          <div>
            <label className="block text-gray-700 font-medium">E-mail</label>
            <input required name="email" type="email" className="w-full border border-gray-300 rounded-lg p-2 mt-1 focus:outline-none focus:ring-2 focus:ring-orange-400" placeholder="seuemail@exemplo.com" />
          </div>
          <div>
            <label className="block text-gray-700 font-medium">Mensagem</label>
            <textarea required name="mensagem" className="w-full border border-gray-300 rounded-lg p-2 mt-1 focus:outline-none focus:ring-2 focus:ring-orange-400" rows={4} placeholder="Conte-nos um pouco sobre o que você busca" />
          </div>
          <Button type="submit" className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-full w-full">Enviar Mensagem</Button>
          {sent && <div className="mt-4 text-green-700 font-semibold">✅ Enviado com sucesso!</div>}
        </form>
      </section>

      <footer className="mt-20 py-6 bg-orange-100 w-full text-center">
        <p className="text-sm text-gray-700">© 2025 Oficina da Mente - Psicologia & Comunidade | Todos os direitos reservados</p>
      </footer>
    </div>
  )
}
