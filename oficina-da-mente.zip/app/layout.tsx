import './globals.css'
import React from 'react'

export const metadata = {
  title: 'Oficina da Mente – Psicologia & Comunidade',
  description: 'Clínica de psicologia para crianças e adolescentes.'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  )
}
