# Oficina da Mente - Landing Page (Next.js)

Projeto pronto para deploy na Vercel.

## Como usar

1. Descompacte o arquivo `oficina-da-mente.zip`.
2. No terminal, dentro da pasta do projeto, rode:
   ```bash
   npm install
   npm run dev
   ```
3. Abra `http://localhost:3000` para visualizar.

## Deploy na Vercel (passo a passo rápido)

1. Faça um repositório no GitHub e comite os arquivos.
2. Acesse https://vercel.com e conecte ao seu GitHub.
3. Importe o repositório e clique em Deploy — o site ficará disponível em segundos.

O formulário no site apenas mostra uma mensagem de sucesso (para demonstração). Para enviar mensagens de verdade, é necessário integrar um backend ou serviço de e-mail/WhatsApp.
